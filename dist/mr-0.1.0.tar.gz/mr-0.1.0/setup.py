# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mr']

package_data = \
{'': ['*']}

install_requires = \
['keyring>=23.0.1,<24.0.0',
 'python-jenkins>=1.7.0,<2.0.0',
 'rich>=10.1.0,<11.0.0',
 'tomlkit>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['mr = mr.mr:main']}

setup_kwargs = {
    'name': 'mr',
    'version': '0.1.0',
    'description': 'CLI to run preconfigured builds with Jenkins',
    'long_description': None,
    'author': 'peres',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
