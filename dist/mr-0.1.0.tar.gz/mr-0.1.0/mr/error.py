class MrError(Exception):
	pass